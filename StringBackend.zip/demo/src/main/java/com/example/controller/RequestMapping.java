package com.example.controller;

public @interface RequestMapping {

    String value();

}
