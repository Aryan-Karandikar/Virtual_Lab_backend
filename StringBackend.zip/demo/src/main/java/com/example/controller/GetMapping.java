package com.example.controller;

public @interface GetMapping {

    String value();

}
