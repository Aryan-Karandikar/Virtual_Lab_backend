package com.example.quiz.repository;

public class QuestionRepository {

}
