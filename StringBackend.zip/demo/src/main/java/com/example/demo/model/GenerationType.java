package com.example.demo.model;

public class GenerationType {

    public static final jakarta.persistence.GenerationType IDENTITY = null;

}
