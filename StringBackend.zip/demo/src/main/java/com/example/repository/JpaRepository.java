package com.example.repository;

public interface JpaRepository<T1, T2> {

}
