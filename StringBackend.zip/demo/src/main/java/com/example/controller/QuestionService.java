package com.example.controller;

import java.util.List;

import com.example.demo.model.Question;

public class QuestionService {

    public void deleteQuestion(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteQuestion'");
    }

    public boolean checkAnswer(Long id, String answer) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'checkAnswer'");
    }

    public List<Question> getAllQuestions() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getAllQuestions'");
    }

    public Question getQuestionById(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getQuestionById'");
    }

    public Question saveQuestion(Question question) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveQuestion'");
    }

}
