package com.example.demo.model;

public @interface Entity {

}
