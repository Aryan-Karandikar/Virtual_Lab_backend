package com.example.controller;

public @interface PostMapping {

    String value();

}
