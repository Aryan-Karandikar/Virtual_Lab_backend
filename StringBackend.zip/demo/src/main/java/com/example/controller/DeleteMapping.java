package com.example.controller;

public @interface DeleteMapping {

    String value();

}
