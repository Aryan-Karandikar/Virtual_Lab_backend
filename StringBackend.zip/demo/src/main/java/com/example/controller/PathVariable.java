package com.example.controller;

public @interface PathVariable {

}
