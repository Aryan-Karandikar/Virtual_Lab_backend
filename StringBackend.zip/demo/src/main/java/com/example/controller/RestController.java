package com.example.controller;

public @interface RestController {

}
