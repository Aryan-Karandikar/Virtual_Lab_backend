package com.example.quiz.repository;

public interface JpaRepository<T1, T2> {

}
