package com.example.repository;


import com.example.demo.model.Question;

import java.util.List;

public interface QuestionRepository extends JpaRepository<Question, Long> {

    List<Question> findAll();

    Object findById(Long id);

    void deleteById(Long id);

    Question save(Question question);
}
